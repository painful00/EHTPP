import numpy as np
import torch
import scipy.sparse as sp

def load_data(path, dataset):
    data_path = path + dataset + ".txt"
    node_set = set()
    source_node_degree = {}
    target_node_degree = {}
    timestamps = []
    temporal_edges = []
    node_history = {}
    f = open(data_path, "r")
    for line in f.readlines():
        ls = line.strip().split()
        source_id = int(ls[0])
        dest_id = int(ls[1])
        time_stamp = float(ls[2])
        node_set.update([source_id, dest_id])
        temporal_edges.append([source_id, dest_id])
        timestamps.append(time_stamp)

        if source_id not in source_node_degree:
            source_node_degree[source_id] = 0
        if dest_id not in source_node_degree:
            source_node_degree[dest_id] = 0

        if source_id not in target_node_degree:
            target_node_degree[source_id] = 0
        if dest_id not in target_node_degree:
            target_node_degree[dest_id] = 0
        source_node_degree[source_id] += 1
        target_node_degree[dest_id] += 1

        if source_id not in node_history:
            node_history[source_id] = []
        if dest_id not in node_history:
            node_history[dest_id] = []
        node_history[source_id].append([dest_id, time_stamp])
        node_history[dest_id].append([source_id, time_stamp])
    f.close()
    temporal_edges = np.array(temporal_edges)
    timestamps = np.array(timestamps)
    return node_set, source_node_degree, target_node_degree, timestamps, temporal_edges, node_history


def negative_sampling_table_initiation(source_node_degree, target_node_degree, negative_sampling_power, negative_edges):
    # degree dependency
    return negative_edges

    # tot_sum, cur_sum, por = 0., 0., 0.
    # n_id = 0
    # id_list = list(node_degree.keys())
    # negative_table = np.zeros((negative_table_size,))
    # for k in node_degree:
    #     tot_sum += np.power(node_degree[k], negative_sampling_power)
    # for k in range(negative_table_size):
    #     if (k + 1.) / negative_table_size > por:
    #         cur_sum += np.power(node_degree[id_list[n_id]], negative_sampling_power)
    #         por = cur_sum / tot_sum
    #         n_id += 1
    #     negative_table[k] = int(id_list[n_id - 1])
    # return negative_table

def history_table_initiation(timestamps):
    max_time = len(timestamps)
    history_table = {}
    for i in range(max_time):
        if len(history_table) == 0:
            history_table[int(timestamps[i])] = i

        elif int(timestamps[i]) in history_table:
            continue
        else:
            history_table[int(timestamps[i])] = i
    return history_table


def negative_sampling(negative_sample, negative_table, node_list):
    sample_node = []
    for i in node_list:
        sample_node.append(np.random.choice(negative_table[i], negative_sample))
    sample_node = np.array(sample_node)
    return sample_node


def negative_edges_sampling(temporal_edges, source_node_num, target_node_num):
    row = np.array(temporal_edges[:, 0])
    col = np.array(temporal_edges[:, 1])
    data = np.ones(len(temporal_edges))
    adjacent = torch.LongTensor(sp.coo_matrix((data, (row, col)), shape=(source_node_num, target_node_num)).todense())
    node_neg_edges = {}
    for i in range(source_node_num):
        node_neg_edges[i] = torch.nonzero(adjacent[i, :] == 0, as_tuple=False).view(-1)
    for i in range(target_node_num):
        node_neg_edges[i] = torch.nonzero(adjacent[i, :] == 0, as_tuple=False).view(-1)

    # node_neg_edges = {}
    # edges = {}
    # module = [n for n in range(source_node_num, source_node_num + target_node_num)]
    # for item in temporal_edges:
    #     if item[0] in edges:
    #         edges[item[0]].append(item[1])
    #     else:
    #         edges[item[0]] = [item[1]]
    # for i in range(source_node_num):
    #     node_neg_edges[i] = torch.LongTensor(np.random.choice(list(set(module).difference(set(edges[i]))), 1000, replace=True))

    return node_neg_edges
