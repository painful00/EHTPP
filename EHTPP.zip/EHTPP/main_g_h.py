import time
import torch
import numpy as np
import argparse
import os
from utils import *
from model_g_h import HTPP, TimeEncode
from torch.optim import SGD, Adam
import random
from poincare import *
from euclidean import *



# Initiation
parser = argparse.ArgumentParser()
parser.add_argument('--path', default="../dataset/", help='Directory of the data file')
parser.add_argument('--save-path', default="./result/", help='Directory of the trained model')
parser.add_argument('--dataset', default="amazon_fasion", help='Name of the network/dataset')
parser.add_argument('--gpu', default=-1, type=int, help='ID of the GPU to run on. If set to -1, CPU will be chosen')
parser.add_argument('--epochs', default=20, type=int, help='Number of epochs to train the model')
parser.add_argument('--embedding-dim', default=128, type=int, help='Number of dimensions of the node embedding')
parser.add_argument('--hidden-dim', default=128, type=int, help='Number of dimensions of the hidden embedding')
parser.add_argument('--time-dim', default=128, type=int, help='Number of dimensions of the time embedding')
parser.add_argument('--batch-size', default=100, type=int, help='Size of each batch')
parser.add_argument('--lr', default=0.001, type=float, help='Number of learning rate')
parser.add_argument('--leakyrelu-rate', default=0.2, type=float, help='rate of leakyrelu function')
parser.add_argument('--negative-sample', default=5, type=int, help='Number of negative samples')
parser.add_argument('--negative-sampling-power', default=0.75, type=float, help='Degree power of negative samples')
parser.add_argument('--hist-nei', default=10, type=int, help='Number of history neighborhood')
parser.add_argument('--hist-link', default=10, type=int, help='Number of history link')
parser.add_argument('--save-step', default=100, type=int, help='Saving model after step')
parser.add_argument('--optimization', default="Adam", help='Model optimizer')
parser.add_argument('--weight-decay', default="0.001", type=float, help='L2 regularization strength')
parser.add_argument('--manifold', default="P", help='P:PoincareBall  E:Euclidean')
parser.add_argument('--c', default=1, type=float, help='The radius of the poincareball')
parser.add_argument('--r', default=2, type=float, help='The coefficient r of Fermi-Dirac function')
parser.add_argument('--s', default=1, type=float, help='The coefficient s of Fermi-Dirac function')
args = parser.parse_args()

# Set GPU
if args.gpu >= 0:
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3,4,5"
    torch.cuda.set_device(args.gpu)
    device = torch.device("cuda:"+str(args.gpu))

# Load Data
node_set, source_node_degree, target_node_degree, timestamps, temporal_edges, node_history = load_data(args.path, args.dataset)
print("Data loading finish!")

# Manifold
if args.manifold == "P":
    manifold = PoincareBall(args.c)
elif args.manifold == "E":
    manifold = Euclidean()

# Split Train_set, Test_set
edges_num = len(temporal_edges)
train_edges = temporal_edges[:int(edges_num*0.9)]
test_edges = temporal_edges[int(edges_num*0.9):]

# negative edges
neg_edges = negative_edges_sampling(temporal_edges, len(source_node_degree), len(target_node_degree))

# negative sampling table initiation
neg_table = negative_sampling_table_initiation(source_node_degree, target_node_degree, args.negative_sampling_power, neg_edges)

# history table initiation
history_table = history_table_initiation(timestamps)


# Model Initiation
if args.gpu >= 0:
    time_encoder = TimeEncode(args.time_dim).to(device)
    model = HTPP(save_path=args.save_path,
                 save_step=args.save_step,
                 epoch_num=args.epochs,
                 hist_nei=args.hist_nei,
                 hist_link=args.hist_link,
                 batch_size=args.batch_size,
                 embedding_dim=args.embedding_dim,
                 hidden_dim=args.hidden_dim,
                 time_dim=args.time_dim,
                 node_num=len(node_set),
                 negative_sample=args.negative_sample,
                 node_history=node_history,
                 history_table=history_table,
                 leakyrule_rate=args.leakyrelu_rate,
                 manifold=manifold,
                 r=args.r,
                 s=args.s,
                 gpu=args.gpu,
                 time_encoder=time_encoder).to(device)
else:
    time_encoder = TimeEncode(args.time_dim)
    model = HTPP(save_path=args.save_path,
                 save_step=args.save_step,
                 epoch_num=args.epochs,
                 hist_nei=args.hist_nei,
                 hist_link=args.hist_link,
                 batch_size=args.batch_size,
                 embedding_dim=args.embedding_dim,
                 hidden_dim=args.hidden_dim,
                 time_dim=args.time_dim,
                 node_num=len(node_set),
                 negative_sample=args.negative_sample,
                 node_history=node_history,
                 history_table=history_table,
                 leakyrule_rate=args.leakyrelu_rate,
                 manifold=manifold,
                 r=args.r,
                 s=args.s,
                 gpu=args.gpu,
                 time_encoder=time_encoder)


# optimizer
optimization = Adam(lr=args.lr, params=model.parameters(), weight_decay=args.weight_decay)
print("Initiation finish!")

# Train Starting
start_time = time.time()
print("Start Training Time:{}   Total Epoch Number:{}".format(time.asctime(time.localtime(start_time)), args.epochs))
best_epoch = -1
best_performance_hit1 = -1
best_performance_hit10 = -1
best_performance_hit50 = -1
best_performance_mrr = -1
best_performance_ndcg20 = -1

id_list = [i for i in range(len(train_edges))]

for epoch in range(args.epochs):
    # Train
    random.shuffle(id_list)
    for batch_id in range(int(len(train_edges) / args.batch_size)):
        if batch_id == int(len(train_edges) / args.batch_size) - 1:
            train_batch_idx = np.array(id_list[batch_id*args.batch_size:])
        else:
            train_batch_idx = np.array(id_list[batch_id*args.batch_size:(batch_id+1)*args.batch_size])
        model.train()
        optimization.zero_grad()
        if args.gpu >= 0:
            loss = model(temporal_edges, timestamps, train_batch_idx, neg_table).to(device)
        else:
            loss = model(temporal_edges, timestamps, train_batch_idx, neg_table)
        loss.backward()
        optimization.step()
        #print("---------Train_epoch:{}   Batch_id:{}/{}   Loss:{:.4f}---------".format(epoch, batch_id, int(len(train_edges) / args.batch_size), loss.item()))


        # Test
        if batch_id % 100 == 0 and batch_id != 0:
            model.eval()
            hit1, hit10, hit50, mrr, ndcg20 = model.evaluation(train_edges, test_edges, neg_edges)
            print("Test_Epoch: {}  Hit@1: {:.4f}  Hit@10: {:.4f}  Hit@50: {:.4f}  MRR: {:.4f}  NDCG@20:{:.4f}".format(epoch, hit1, hit10, hit50, mrr, ndcg20))
            print("---------Train_epoch:{}   Batch_id:{}/{}   Loss:{:.4f}---------".format(epoch, batch_id, int(
                len(train_edges) / args.batch_size), loss.item()))
            if best_performance_hit1 < hit1:
                best_performance_hit1 = hit1
            if best_performance_hit10 < hit10:
                best_performance_hit10 = hit10
            if best_performance_hit50 < hit50:
                best_performance_hit50 = hit50
            if best_performance_ndcg20 < ndcg20:
                best_performance_ndcg20 = ndcg20
            if best_performance_mrr < mrr:
                best_performance_mrr = mrr
                best_epoch = epoch
                #torch.save(model.state_dict(), args.save_path+args.dataset+"_epoch_"+str(epoch)+"_model")

    print("Best_Epoch: {}  Hit@1: {:.4f}  Hit@10: {:.4f}  Hit@50: {:.4f}  MRR: {:.4f}  NDCG@20: {:.4f}".format(best_epoch, best_performance_hit1, best_performance_hit10, best_performance_hit50, best_performance_mrr, best_performance_ndcg20))
end_time = time.time()
print("End Training    Time:" + time.asctime(time.localtime(end_time)))
print("Total Training Time Cost:"+str(end_time-start_time)+"s")
