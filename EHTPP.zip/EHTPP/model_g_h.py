import torch
import numpy as np
from torch.nn.modules.module import Module
from torch.autograd import Variable
from utils import *
from sklearn.linear_model import LogisticRegression
from torch.nn.functional import softmax
import scipy.sparse as sp
from sklearn.metrics import roc_auc_score
from sklearn.metrics import f1_score
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
import torch.nn as nn
import math


class HTPP(Module):
    def __init__(self, save_path, save_step, epoch_num, hist_nei, hist_link, batch_size, embedding_dim, time_dim, hidden_dim, node_num, negative_sample, node_history, history_table, leakyrule_rate, manifold, r, s, gpu, time_encoder):
        super(HTPP, self).__init__()
        self.save_path = save_path
        self.save_step = save_step
        self.epoch_num = epoch_num
        self.hist_nei = hist_nei
        self.hist_link = hist_link
        self.batch_size = batch_size
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.node_num = node_num
        self.negative_sample = negative_sample
        self.node_history = node_history
        self.history_table = history_table
        self.leakyrelu = torch.nn.LeakyReLU(leakyrule_rate)
        self.time_dim = time_dim
        self.time_encoder = time_encoder
        self.gpu = gpu
        self.manifold = manifold
        self.r = r
        self.s = s

        # node embedding
        self.node_emb = torch.nn.Parameter(torch.zeros(size=(self.node_num, self.embedding_dim), dtype=torch.float64))
        torch.nn.init.xavier_uniform_(self.node_emb, gain=1.414)

        # Local LeakRule Attention
        self.W_a_l = torch.nn.Parameter(torch.zeros(size=(self.embedding_dim, self.hidden_dim), dtype=torch.float64))
        torch.nn.init.xavier_uniform_(self.W_a_l.data, gain=1.414)
        self.a_l = torch.nn.Parameter(torch.zeros(size=(2 * self.hidden_dim, 1), dtype=torch.float64))
        torch.nn.init.xavier_uniform_(self.a_l.data, gain=1.414)

        # Local coefficient
        if self.gpu >= 0:
            self.beta1 = Variable((torch.ones(1).cuda()), requires_grad=True)
        else:
            self.beta1 = Variable((torch.ones(1)), requires_grad=True)

        # time cofficient
        self.sigma_time_cofficient = torch.nn.Parameter(torch.zeros(size=(self.node_num, 1), dtype=torch.float64))
        torch.nn.init.xavier_uniform_(self.sigma_time_cofficient, gain=1.414)

        # global LeakRule Attention
        self.W_a_g = torch.nn.Parameter(torch.zeros(size=(self.embedding_dim, self.hidden_dim), dtype=float))
        torch.nn.init.xavier_uniform_(self.W_a_g.data, gain=1.414)
        self.a_g = torch.nn.Parameter(torch.zeros(size=(2 * self.hidden_dim, 1), dtype=torch.float64))
        torch.nn.init.xavier_uniform_(self.a_g.data, gain=1.414)


        # global coefficient
        if self.gpu >= 0:
            self.beta2 = Variable((torch.ones(1).cuda()), requires_grad=True)
        else:
            self.beta2 = Variable((torch.ones(1)), requires_grad=True)


        # time coefficient
        self.delta_l = Variable((torch.zeros(self.node_num) + 1.), requires_grad=True)
        self.delta_g = Variable((torch.zeros(self.node_num) + 1.), requires_grad=True)




    def forward(self, temporal_edges, timestamps, edges_batch_idx, neg_table):
        loss = 0
        train_data = temporal_edges[edges_batch_idx]
        train_time = timestamps[edges_batch_idx]
        source_embedding = self.node_emb[train_data[:, 0]]
        target_embedding = self.node_emb[train_data[:, 1]]
        source_neg_sampling = torch.LongTensor(negative_sampling(self.negative_sample, neg_table, train_data[:, 1])).view(source_embedding.size()[0], -1)
        target_neg_sampling = torch.LongTensor(negative_sampling(self.negative_sample, neg_table, train_data[:, 0])).view(target_embedding.size()[0], -1)

        # positive lambda
        lambda_positive = self.lambda_calculator(train_data, train_time, source_embedding, target_embedding, temporal_edges, timestamps)

        # negative lambda
        lambda_negative_source = 0
        lambda_negative_target = 0

        sns = source_neg_sampling.view(-1, 1)
        dst = torch.LongTensor(np.array([train_data[:, 1]])).view(-1, 1).repeat(1, self.negative_sample).view(-1, 1)
        neg_sam = torch.cat((sns, dst), dim=1).numpy()
        tms = torch.LongTensor(np.array([train_time])).view(-1, 1).repeat(1, self.negative_sample).view(-1, 1).numpy()
        neg_source_embedding = self.node_emb[neg_sam[:, 0]]
        neg_target_embedding = self.node_emb[neg_sam[:, 1]]
        lambda_negative_source = self.lambda_calculator(neg_sam, tms, neg_source_embedding, neg_target_embedding, temporal_edges, timestamps)

        dns = target_neg_sampling.view(-1, 1)
        sor = torch.LongTensor(np.array([train_data[:, 0]])).view(-1, 1).repeat(1, self.negative_sample).view(-1, 1)
        neg_sam = torch.cat((sor, dns), dim=1).numpy()
        tms = torch.LongTensor(np.array([train_time])).view(-1, 1).repeat(1, self.negative_sample).view(-1, 1).numpy()
        neg_source_embedding = self.node_emb[neg_sam[:, 0]]
        neg_target_embedding = self.node_emb[neg_sam[:, 1]]
        lambda_negative_target = self.lambda_calculator(neg_sam, tms, neg_source_embedding, neg_target_embedding, temporal_edges, timestamps)

        if self.gpu >= 0:
            positive = F.binary_cross_entropy(lambda_positive, torch.ones_like(lambda_positive).cuda())
            negative_source = F.binary_cross_entropy(lambda_negative_source, torch.zeros_like(lambda_negative_source).cuda())
            negative_target = F.binary_cross_entropy(lambda_negative_target, torch.zeros_like(lambda_negative_target).cuda())
            loss = positive + negative_source + negative_target
        else:
            positive = F.binary_cross_entropy(lambda_positive, torch.ones_like(lambda_positive))
            negative_source = F.binary_cross_entropy(lambda_negative_source, torch.zeros_like(lambda_negative_source))
            negative_target = F.binary_cross_entropy(lambda_negative_target, torch.zeros_like(lambda_negative_target))
            loss = positive + negative_source + negative_target

        #loss = - torch.log(torch.sigmoid(torch.exp(lambda_positive))).sum() - torch.log(torch.sigmoid(torch.exp(lambda_negative_source).neg())).sum() / self.negative_sample - torch.log(torch.sigmoid(torch.exp(lambda_negative_target).neg())).sum() / self.negative_sample

        return loss

    def evaluation(self, train_edges, test_edges, neg_edges):
        with torch.no_grad():
            accuracy = 0
            f1 = 0
            hit_1 = 0
            hit_10 = 0
            hit_50 = 0
            mrr = 0
            ndcg_20 = 0

            query_user = {}
            for item in test_edges:
                if item[0] not in query_user:
                    query_user[item[0]] = set([item[1]])
                else:
                    query_user[item[0]].add(item[1])

            for user in query_user:
                item_list = np.random.choice(neg_edges[user], 100, replace=True).tolist() + list(query_user[user])
                dist = ((self.node_emb[user].view(1, self.embedding_dim).repeat(len(item_list), 1) - self.node_emb[item_list])**2).sum(1).neg()
                _, indices = dist.topk(50, dim=0)

                dcg_20 = 0
                idcg_20 = 0
                for ind, val in enumerate(indices):
                    if ind == 0 and val >= 100:
                        hit_1 += 1
                        hit_10 += 1
                        hit_50 += 1
                        mrr += 1.0 / (ind + 1.0)
                        break
                    if ind < 10 and val >= 100:
                        hit_10 += 1
                        hit_50 += 1
                        mrr += 1.0 / (ind + 1.0)
                        break
                    if ind < 50 and val >= 100:
                        hit_50 += 1
                        mrr += 1.0 / (ind + 1.0)
                        break
                    if ind >= 50 and val >= 100:
                        mrr += 1.0 / (ind + 1.0)
                        break
                for ind, val in enumerate(indices):
                    if ind < 20 and val >= 100:
                        dcg_20 += (1 / math.log(ind + 2.0, 2))
                    if ind < 20 and ind < len(query_user[user]):
                        idcg_20 += (1 / math.log(ind + 2.0, 2))
                    if ind >= 20:
                        break
                ndcg_20 += dcg_20 / idcg_20

            hit_1 = hit_1 / len(query_user)
            hit_10 = hit_10 / len(query_user)
            hit_50 = hit_50 / len(query_user)
            mrr = mrr / len(query_user)
            ndcg_20 = ndcg_20 / len(query_user)

        return hit_1, hit_10, hit_50, mrr, ndcg_20

    def get_history(self, source_id, dest_id, his_len, timestamp):
        source_history_emb = torch.zeros((len(source_id), self.hist_nei, self.embedding_dim), dtype=torch.float64)
        if self.gpu >= 0:
            source_history_emb = source_history_emb.cuda()
        source_history_time = []
        dest_history_emb = torch.zeros((len(source_id), self.hist_nei, self.embedding_dim), dtype=torch.float64)
        if self.gpu >= 0:
            dest_history_emb = dest_history_emb.cuda()
        dest_history_time = []
        zero_padding = Variable(torch.zeros((1, self.embedding_dim), dtype=torch.float64))
        if self.gpu >= 0:
            zero_padding = zero_padding.cuda()
        for idx, nid in enumerate(source_id):
            history_source_temp = []
            history_dest_temp = []
            source_his = self.node_history[source_id[idx]]
            dest_his = self.node_history[dest_id[idx]]

            for item in source_his:
                if item[1] < timestamp[idx]:
                    history_source_temp.append(item)
                else:
                    break
            history_source_temp = np.array(history_source_temp)
            if his_len < len(history_source_temp):
                history_source_temp = history_source_temp[-his_len:]
                source_history_emb[idx] = self.node_emb[history_source_temp[:, 0]]
                source_history_time.append(history_source_temp[:, 1])
            elif len(history_source_temp) > 0:
                source_history_emb[idx] = torch.cat((self.node_emb[history_source_temp[:, 0]], zero_padding.repeat(his_len-len(history_source_temp), 1)), dim=0)
                source_history_time.append(history_source_temp[:, 1].tolist() + [float(timestamp[idx]) for _ in range(his_len-len(history_source_temp))])
            elif len(history_source_temp) == 0:
                source_history_time.append([float(timestamp[idx]) for _ in range(his_len)])

            for item in dest_his:
                if item[1] < timestamp[idx]:
                    history_dest_temp.append(item)
                else:
                    break
            history_dest_temp = np.array(history_dest_temp)
            if his_len < len(history_dest_temp):
                history_dest_temp = history_dest_temp[-his_len:]
                dest_history_emb[idx] = self.node_emb[history_dest_temp[:, 0]]
                dest_history_time.append(history_dest_temp[:, 1])
            elif len(history_dest_temp) > 0:
                dest_history_emb[idx] = torch.cat((self.node_emb[history_dest_temp[:, 0]], zero_padding.repeat(his_len - len(history_dest_temp), 1)), dim=0)
                dest_history_time.append(history_dest_temp[:, 1].tolist() + [float(timestamp[idx]) for _ in range(his_len - len(history_dest_temp))])
            elif len(history_dest_temp) == 0:
                dest_history_time.append([float(timestamp[idx]) for _ in range(his_len)])

        return source_history_emb, source_history_time, dest_history_emb, dest_history_time

    def get_history_link(self, train_data, temporal_edges, timestamps, train_time, history_table):
        links_emb_source = torch.zeros((len(train_data), self.hist_link, self.embedding_dim), dtype=torch.float64)
        if self.gpu >= 0:
            links_emb_source = links_emb_source.cuda()
        links_emb_dest = torch.zeros((len(train_data), self.hist_link, self.embedding_dim), dtype=torch.float64)
        if self.gpu >= 0:
            links_emb_dest = links_emb_dest.cuda()
        zero_padding = Variable(torch.zeros((1, self.embedding_dim), dtype=torch.float64))
        if self.gpu >= 0:
            zero_padding = zero_padding.cuda()
        links_time = []
        for idx in range(len(train_time)):
            index = history_table[int(train_time[idx])]
            if index >= self.hist_link:
                links_emb_source[idx] = self.node_emb[temporal_edges[(index-self.hist_link):index, 0]]
                links_emb_dest[idx] = self.node_emb[temporal_edges[(index - self.hist_link):index, 1]]
                links_time.append(timestamps[(index-self.hist_link):index])
            elif index > 0:
                links_emb_source[idx] = torch.cat((self.node_emb[temporal_edges[:index, 0]], zero_padding.repeat((self.hist_link - index), 1)), dim=0)
                links_emb_dest[idx] = torch.cat((self.node_emb[temporal_edges[:index, 1]], zero_padding.repeat((self.hist_link - index), 1)), dim=0)
                links_time.append(timestamps[:index].tolist() + [timestamps[idx] for _ in range(self.hist_link - index)])
            else:
                links_time.append([timestamps[idx] for _ in range(self.hist_link)])
        return links_emb_source, links_emb_dest, links_time


    def lambda_calculator(self, train_data, train_time, source_embedding, target_embedding, temporal_edges, timestamps):
        mu_ij = self.manifold.sqdist(source_embedding, target_embedding).neg()
        lambda_local = 0
        lambda_global = 0
        his_i_emb, his_i_time, his_j_emb, his_j_time = self.get_history(train_data[:, 0], train_data[:, 1], self.hist_nei, train_time)

        # local

        # hidden representation
        source_hidden = torch.matmul(self.manifold.logmap0(source_embedding).repeat(1, self.hist_nei).view(-1, self.hist_nei,self.embedding_dim), self.W_a_l)
        target_hidden = torch.matmul(self.manifold.logmap0(target_embedding).repeat(1, self.hist_nei).view(-1, self.hist_nei,self.embedding_dim), self.W_a_l)
        his_i_hidden = torch.matmul(self.manifold.logmap0(his_i_emb), self.W_a_l)
        his_j_hidden = torch.matmul(self.manifold.logmap0(his_j_emb), self.W_a_l)


        # time influence
        if self.gpu >= 0:
            local_time_influence_i = self.time_encoder(self.sigma_time_cofficient[train_data[:, 0]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_nei).cuda() - torch.LongTensor(np.array(his_i_time)).view(-1, self.hist_nei).cuda()))
        else:
            local_time_influence_i = self.time_encoder(self.sigma_time_cofficient[train_data[:, 0]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_nei) - torch.LongTensor(np.array(his_i_time)).view(-1, self.hist_nei)))
        local_time_influence_i = local_time_influence_i.mean(2)
        if self.gpu >= 0:
            local_time_influence_j = self.time_encoder(self.sigma_time_cofficient[train_data[:, 1]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_nei).cuda() - torch.LongTensor(np.array(his_j_time)).view(-1, self.hist_nei).cuda()))
        else:
            local_time_influence_j = self.time_encoder(self.sigma_time_cofficient[train_data[:, 1]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_nei) - torch.LongTensor(np.array(his_j_time)).view(-1, self.hist_nei)))
        local_time_influence_j = local_time_influence_j.mean(2)

        # attention
        score_i = self.leakyrelu(torch.matmul(torch.cat((source_hidden, his_i_hidden), dim=2), self.a_l)).view(-1, self.hist_nei)
        score_i_time = score_i * local_time_influence_i
        score_i_tol = softmax(score_i_time, dim=1).unsqueeze(2).expand(his_i_emb.size()[0], his_i_emb.size()[1], his_i_emb.size()[2])
        score_j = self.leakyrelu(torch.matmul(torch.cat((target_hidden, his_j_hidden), dim=2), self.a_l)).view(-1, self.hist_nei)
        score_j_time = score_j * local_time_influence_j
        score_j_tol = softmax(score_j_time, dim=1).unsqueeze(2).expand(his_j_emb.size()[0], his_j_emb.size()[1], his_j_emb.size()[2])
        print(score_j_tol)
        # local influence
        local_i = torch.sum(torch.mul(score_i_tol, self.manifold.logmap0(his_i_emb)), dim=1)
        local_j = torch.sum(torch.mul(score_j_tol, self.manifold.logmap0(his_j_emb)), dim=1)

        # distance calculation
        lambda_local = self.manifold.sqdist(self.manifold.expmap0(local_i), target_embedding).neg() * self.beta1 + self.manifold.sqdist(source_embedding, self.manifold.expmap0(local_j)).neg() * self.beta1
        #lambda_local = self.manifold.sqdist(self.manifold.expmap0(local_i), self.manifold.expmap0(local_j)).neg() * self.beta1
        #lambda_local = ((local_i - local_j) ** 2).sum(dim=1).neg() * self.beta1


        # global
        his_link_source_emb, his_link_target_emb, his_link_time = self.get_history_link(train_data, temporal_edges, timestamps, train_time, self.history_table)

        # hidden representation
        his_link_source_hidden = torch.matmul(self.manifold.logmap0(his_link_source_emb), self.W_a_g)
        his_link_target_hidden = torch.matmul(self.manifold.logmap0(his_link_target_emb), self.W_a_g)
        source_his_hidden = torch.matmul(self.manifold.logmap0(source_embedding).repeat(1, self.hist_link).view(-1, self.hist_link, self.embedding_dim), self.W_a_g)
        target_his_hidden = torch.matmul(self.manifold.logmap0(target_embedding).repeat(1, self.hist_link).view(-1, self.hist_link, self.embedding_dim), self.W_a_g)

        # time influence
        if self.gpu >= 0:
            global_time_influence_i = self.time_encoder(self.sigma_time_cofficient[train_data[:, 0]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_link).cuda() - torch.LongTensor(np.array(his_link_time)).view(-1, self.hist_link).cuda()))
        else:
            global_time_influence_i = self.time_encoder(self.sigma_time_cofficient[train_data[:, 0]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_link) - torch.LongTensor(np.array(his_link_time)).view(-1, self.hist_link)))
        global_time_influence_i = global_time_influence_i.mean(2)
        if self.gpu >= 0:
            global_time_influence_j = self.time_encoder(self.sigma_time_cofficient[train_data[:, 1]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_link).cuda() - torch.LongTensor(np.array(his_link_time)).view(-1, self.hist_link).cuda()))
        else:
            global_time_influence_j = self.time_encoder(self.sigma_time_cofficient[train_data[:, 1]] * (torch.LongTensor(np.array(train_time)).view(-1, 1).repeat(1, self.hist_link) - torch.LongTensor(np.array(his_link_time)).view(-1, self.hist_link)))
        global_time_influence_j = global_time_influence_j.mean(2)

        # attention
        score_source = self.leakyrelu(torch.matmul(torch.cat((his_link_source_hidden, source_his_hidden), dim=2), self.a_g)).view(-1, self.hist_link)
        score_source_time = score_source * global_time_influence_i
        score_source_tol = softmax(score_source_time, dim=1).unsqueeze(2).expand(his_link_source_emb.size()[0], his_link_source_emb.size()[1], his_link_source_emb.size()[2])
        score_target = self.leakyrelu(torch.matmul(torch.cat((his_link_target_hidden, target_his_hidden), dim=2), self.a_g)).view(-1, self.hist_link)
        score_target_time = score_target * global_time_influence_j
        score_target_tol = softmax(score_target_time, dim=1).unsqueeze(2).expand(his_link_target_emb.size()[0], his_link_target_emb.size()[1], his_link_target_emb.size()[2])

        # global influence
        global_i = torch.sum(torch.mul(score_source_tol, self.manifold.logmap0(his_link_source_emb)), dim=1)
        global_j = torch.sum(torch.mul(score_target_tol, self.manifold.logmap0(his_link_target_emb)), dim=1)

        print(score_target_tol)
        # distance calculation

        lambda_global = self.manifold.sqdist(self.manifold.expmap0(global_i), self.manifold.expmap0(global_j)).neg() * self.beta2
        # lambda_global = ((global_i - global_j) ** 2).sum(dim=1).neg() * self.beta2

        # total lambda
        lambda_total = torch.sigmoid(mu_ij + lambda_local + lambda_global)

        return lambda_total


class TimeEncode(torch.nn.Module):
    def __init__(self, expand_dim, factor=5):
        super(TimeEncode, self).__init__()

        time_dim = expand_dim
        self.factor = factor
        self.basis_freq = torch.nn.Parameter((torch.from_numpy(1 / 10 ** np.linspace(0, 9, time_dim))).float())
        self.phase = torch.nn.Parameter(torch.zeros(time_dim).float())

    def forward(self, ts):
        # ts: [N, L]
        batch_size = ts.size(0)
        seq_len = ts.size(1)

        ts = ts.view(batch_size, seq_len, 1)  # [N, L, 1]
        map_ts = ts * self.basis_freq.view(1, 1, -1)  # [N, L, time_dim]
        map_ts += self.phase.view(1, 1, -1)

        harmonic = torch.cos(map_ts)

        return harmonic